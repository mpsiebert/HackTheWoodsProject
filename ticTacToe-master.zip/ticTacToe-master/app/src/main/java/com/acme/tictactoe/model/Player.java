package com.acme.tictactoe.model;

enum Player { X , O }
